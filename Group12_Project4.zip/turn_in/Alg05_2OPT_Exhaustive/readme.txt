to compile:

simply type 'make' at the command line

usage:

tsp_2opt INPUTFILE
