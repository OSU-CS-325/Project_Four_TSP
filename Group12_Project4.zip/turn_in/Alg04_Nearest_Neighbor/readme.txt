usage:

/usr/bin/python3 nearestNeighbor.py INPUTFILE
