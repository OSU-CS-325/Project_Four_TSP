usage:

/usr/bin/python3 braindeadTour.py INPUTFILE
