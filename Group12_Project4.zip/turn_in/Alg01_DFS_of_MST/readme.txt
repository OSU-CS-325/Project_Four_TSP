usage:

/usr/bin/python3 DFSofMST.py INPUTFILE
